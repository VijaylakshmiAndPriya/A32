/**
 * 
 */
/**
 * 
 */
module Assignment32 {
	requires java.desktop;
}