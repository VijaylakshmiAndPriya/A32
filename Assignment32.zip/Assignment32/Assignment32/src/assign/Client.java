package assign;

import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

public class Client {
	private int timeout = 5000; // Set your desired timeout in milliseconds
	private volatile boolean receiving = true;
	private String DEFAULT_TM = "00010 01000 10010 11000";
	
	private JTextArea logTextArea;
    private JTextField userTextArea, serverTextArea, portTextArea, tmTextArea;
    private JButton sendButton, receiveButton, connectButton, endButton, validateButton, runButton;
    private JFrame frame;
    private JLabel label3, label4;
    private JLabel label1;
    private JLabel label2;
    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;
    String receivedMessage;

    public Client(int currentClientNumber) {
    	frame = new JFrame("Client #"+currentClientNumber + "           C/S Turing Machine - JAP (Fall 2023)");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setResizable(false);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
            	disconnectFromServer();
            }
        });
        
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(Color.LIGHT_GRAY);
     
        logTextArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(logTextArea);
        scrollPane.setPreferredSize(new Dimension(535, 95)); // Set width and height
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
  
        userTextArea = new JTextField(7);
        userTextArea.setText("User"+currentClientNumber);
        serverTextArea = new JTextField(7);
        serverTextArea.setText("localhost");
        portTextArea = new JTextField(7);
        portTextArea.setText("12345");
        tmTextArea = new JTextField(15);
        tmTextArea.setText(DEFAULT_TM);
        label3 = new JLabel("User");
        label1 = new JLabel("Server");
        label2 = new JLabel("Port");
        label4 = new JLabel("TM:");
        label4.setPreferredSize(new Dimension(50, 25)); // Set width and height
        sendButton = new JButton("Send");
        receiveButton = new JButton("Receive"); // Added button
        connectButton = new JButton ("Connect");
        endButton = new JButton ("End");
        endButton.setPreferredSize(new Dimension(75, 25)); // Set width and height
        validateButton = new JButton ("Validate");
        runButton = new JButton ("Run");
        
        // bottom panel secion
        JPanel bottomPanel3 = new JPanel();
        JPanel bottompanel4 = new JPanel();
     
        bottomPanel3.add(label3);
        bottomPanel3.add(userTextArea);
        bottomPanel3.add(label1);
        bottomPanel3.add(serverTextArea);
        bottomPanel3.add(label2);
        bottomPanel3.add(portTextArea);
        bottomPanel3.add(connectButton);
        bottomPanel3.add(endButton);
        bottompanel4.add(label4);
        bottompanel4.add(tmTextArea);
        bottompanel4.add(validateButton); 
        bottompanel4.add(sendButton);
        bottompanel4.add(receiveButton);
        bottompanel4.add(runButton);
 
        JPanel topPanel1 = new JPanel();
        // Load the image for the top panel
        ImageIcon image = new ImageIcon("tm-client.png");
        JLabel imageLabel = new JLabel(image);
        topPanel1.add(imageLabel, BorderLayout.NORTH);
   
        JPanel centerPanel2 = new JPanel();
        //centerPanel2.setBorder(BorderFactory.createTitledBorder(panelName));
        centerPanel2.setPreferredSize(new Dimension(580, 110));
        centerPanel2.add(scrollPane);
 
         mainPanel.add(topPanel1);
         mainPanel.add(centerPanel2);
         mainPanel.add(bottomPanel3);
         mainPanel.add(bottompanel4);
   
         connectButton.addActionListener(new ActionListener() {
        	int portNumber;
            @Override
            public void actionPerformed(ActionEvent e) {
            	
            	// validate for server name before connecting
                String serverName = serverTextArea.getText();
                if (serverName != null && !serverName.isEmpty()) {
                    
                } else  {
                    log("Server name cannot be empty");
                }
            	
                // validate for port number before connecting
                String clientName = userTextArea.getText();
                if (clientName != null && !clientName.isEmpty()) {
                    
                } else  {
                    log("Client name cannot be empty");
                }
              	
            	//validate for port number before connecting
            	String numberText = portTextArea.getText();
            	if (numberText != null && !numberText.isEmpty()) {
            		try {
                         portNumber = Integer.parseInt(numberText);
                    } catch (NumberFormatException ex) {
                         System.err.println("Invalid number format: " + numberText); // Handle the case where the text is not a valid integer
                    }
                } else  {
                	log("Port number cannot be empty");
                }
            	
               if (connectToServer(clientName, portNumber, serverName)) {
            	   connectButton.setText("Connected");
               }
            }
        });

        endButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	 if (disconnectFromServer()) {
              	   connectButton.setText("Connect");
                 }
            	
            }
        });
        
        runButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	TuringMachine TM = new TuringMachine();
            	if (receivedMessage != null) {
                   TM.initComponents(receivedMessage);
                } else {
                	TM.initComponents(DEFAULT_TM);
                }
            }
        });
        
        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendMessage();
            }
        });

        receiveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               	receiveMessage();
            }
        });

        validateButton.addActionListener(new ActionListener() {
        	@Override
            public void actionPerformed(ActionEvent e) {
            	isValidTuringMachine(tmTextArea.getText()); 
            }
        });
        
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
 
       // Set a preferred size for the button panel
        buttonPanel.setPreferredSize(new Dimension(0, 80));

        frame.add(mainPanel, "North");     
        frame.setSize(575, 350);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }

    private void sendMessage() {
        String message = tmTextArea.getText();
        if (message != null) {
            out.println(message);
        }
    }

    private void receiveMessage() {
    	receiving = true;
    	long startTime = System.currentTimeMillis();
    	// Continuously check for incoming messages from the server in a separate thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (receiving) {
                        if (clientSocket != null && clientSocket.isConnected() && in.ready()) {
                            receivedMessage = in.readLine(); // decleare in the class to access by all the methods
                            if (receivedMessage != null) {
                                log("Received from server: " + receivedMessage);
                            } else {
                            	log("No message to received from the server.");
                            }
                        }

                        // You can customize the timeout duration based on your needs
                        if (timeoutReached(startTime)) {
                            stopReceiving(); // stop waiting for the new message.
                        }
                    }
                } catch (IOException e) {
                    log("Error receiving message: " + e.getMessage());
                }
            }
        }).start();
    }

    private boolean timeoutReached(long startTime) {
        long currentTime = System.currentTimeMillis();
        long timeoutDuration = 1000; // one seconds timeout

        return (currentTime - startTime) > timeoutDuration;
    }

    private void stopReceiving() {
        receiving = false;
    }
   
    private boolean connectToServer(String clientName, int portNumber, String serverName) {
        try {
            clientSocket = new Socket();
            clientSocket.connect(new java.net.InetSocketAddress(serverName, portNumber), timeout);

            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
           
            out.println(clientName); // Send the client name to the server during connection
            
            // Wait for acknowledgment from the server
            String ack = in.readLine();
            if ("ACCEPTED".equals(ack)) {
            	log("Connected to the server : "+ serverTextArea.getText());
            	return true;
            } else if ("REJECTED".equals(ack)) {
            	log("Connection rejected by the server: "+ serverTextArea.getText());
            	return false;
            }	
      
        } catch (SocketTimeoutException e) {
            // Connection attempt timed out
        	log("Connection to the server timed out."); 
        } catch (IOException e) {
            log("Error connecting to the server: " + e.getMessage());
        }
		return true;
    }
    
    private boolean disconnectFromServer() {
        try {
            if (clientSocket != null) {
                clientSocket.close();
                log("Disconnected from the server\n");
                return true;
            }
        } catch (IOException e) {
            System.err.println("Error closing the connection: " + e.getMessage());
            return false;
        }
        
        return true;
    }
    
    public void isValidTuringMachine(String tuples) {
        // Split the tuples into individual entries
        String[] tupleArray = tuples.split(" ");

        // Check if each tuple is valid
        for (String tuple : tupleArray) {
            if (isValidTuple(tuple)) {
            	log(tuple + " is a valid tuple.");
            } else {
            	log(tuple + " is an invalid tuple.");
            }
        }
    }

    public static boolean isValidTuple(String tuple) {
        // Check if the tuple has exactly 5 characters
        if (tuple.length() != 5) {
            return false;
        }

        // Check if each character is either '0' or '1'
        for (char c : tuple.toCharArray()) {
            if (c != '0' && c != '1') {
                return false;
            }
        }

        return true;
    }

    public void log(String message) {
    	logTextArea.append(message + "\n");
	}
}