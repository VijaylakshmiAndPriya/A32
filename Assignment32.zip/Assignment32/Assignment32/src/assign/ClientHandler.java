package assign;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.SwingUtilities;

public class ClientHandler implements Runnable {
	private static int nextId = 1; // Static variable to generate unique IDs
    private int clientId; // Unique ID for each client
	private Socket clientSocket;
    private Server server;
    private PrintWriter out;
    private BufferedReader in;
    private String clientName;

    public ClientHandler(Socket socket, Server server, String clientName) {
        this.clientSocket = socket;
        this.server = server;
        this.clientName = clientName;
        this.clientId = nextId++; // Assign a unique ID to the client
        
        try {
            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        } catch (IOException e) {
            server.log("Error setting up client handler: " + e.getMessage());
        }
    }

 // Inside your ClientHandler class

    @Override
    public void run() {
        try {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                final String message = "Message received from the client("+ clientName + "): " + inputLine;

                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        server.log(message);
                    }
                });

                // Broadcast message to all other clients
                //server.broadcastToClients("Client at " + clientName + " says: " + inputLine, this);
                server.broadcastToClients(inputLine, this);
            }
        } catch (IOException e) {
            server.log("Error handling client input: " + e.getMessage());
        } finally {
            close();
            server.clientDisconnected(clientName);  
        }
    }

    public void sendMessage(String message) {
        out.println(message);
    }

    public void close() {
        try {
            in.close();
            out.close();
            clientSocket.close();
            server.log("Client disconnected: " + clientSocket.getInetAddress().getHostAddress());
        } catch (IOException e) {
            server.log("Error closing client handler: " + e.getMessage());
        }
    }
}