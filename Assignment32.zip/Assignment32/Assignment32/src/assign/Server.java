package assign;

import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {
	private boolean acceptClient= true; // Set your desired maximum number of clients
    private int connectedClients = 0;
    private boolean serverStarted = false;
	
    private JTextArea logTextArea;
    private JTextField portTextArea;
    private JButton startButton, modelButton;
    private JButton endButton;
    private JButton sendToClientsButton; // Added button
    private JFrame frame;
    private JLabel label1;
    private JLabel statusBar;
    private JCheckBox checkBox;
    private ServerSocket serverSocket;
    private List<ClientHandler> clients;

    public Server() {
    	 clients = new ArrayList<>();
    	
    	frame = new JFrame("Server");
        frame.setResizable(false);
        frame.setSize(585, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    	
    	frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
            	if (serverStarted) {
            		stopServer();
            	}
            }
        });
    	
        logTextArea = new JTextArea();
        
        JScrollPane scrollPane = new JScrollPane(logTextArea);
        scrollPane.setPreferredSize(new Dimension(525, 150)); // Set width and height
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        
        portTextArea = new JTextField(5);
        portTextArea.setText("12345");
        label1 = new JLabel("Port");
        startButton = new JButton("Start");
        modelButton = new JButton("Model");
        checkBox = new JCheckBox("Finalizes");
        endButton = new JButton("End");
        
      
        sendToClientsButton = new JButton("Send to Clients"); // Added button
              
        JPanel panel = new JPanel ();
		panel.setLayout(new FlowLayout( 100));	
    	panel.setBackground(Color.LIGHT_GRAY);
		ImageIcon image = new ImageIcon ("tm-server.png"); 
		JLabel label = new JLabel(image);
		panel.add(label, BorderLayout.NORTH);

        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startServer();
            }
        });

        endButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stopServer();
            }
        });

        sendToClientsButton.addActionListener(new ActionListener() { // Added action listener
            @Override
            public void actionPerformed(ActionEvent e) {
                sendToClients();
            }
        });

        // Add an ActionListener to the checkbox
        checkBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkBox.isSelected()) {
                	acceptClient = false;
                	log("Server cannot accept anymore clients.");
                	
                } else {
                	log("Server can accept clients...");
                	acceptClient = true;
                }
            }
        });
        
        JPanel panel11 = new JPanel();
        panel11.add(label1);
        panel11.add(portTextArea);       
        panel11.add(startButton);
        panel11.add(modelButton);
        panel11.add(checkBox);
        panel11.add(endButton);
        panel11.add(sendToClientsButton); // Added button
       
        frame.add(panel, "North");
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(panel11, "South");  
    }

        
    private void startServer() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    
                	String numberText = portTextArea.getText();
                    try {
                        int portNumber = Integer.parseInt(numberText);
                        serverSocket = new ServerSocket(portNumber);
                        log("Server started...\nport = "+portNumber+" \nWaiting for clients to connect...");
                        serverStarted = true;
                    } catch (NumberFormatException ex) {
                        
                        System.err.println("Invalid number format: " + numberText); // Handle the case where the text is not a valid integer
                        serverStarted = false;
                    }
    
                    while (true) {
                    	Socket clientSocket = serverSocket.accept();
                      	if(acceptClient == true) {
                    		String clientName = getClientName(clientSocket);
	                        //log("New client connected: " + clientSocket.getInetAddress().getHostAddress());
	                        log("Client connected: " + clientName);
	                        
	                        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
	                        out.println("ACCEPTED"); // Send acknowledgment to the client		
	                        
	                        ClientHandler clientHandler = new ClientHandler(clientSocket, Server.this, clientName);
	                        clients.add(clientHandler);
	                        new Thread(clientHandler).start();
	                        
	                        connectedClients++; // Increment connected clients count
	                        log("Number of clients connected: "+ connectedClients);
                        } else {
                        	rejectConnection(clientSocket);                       
                        }
                    }
                } catch (IOException e) {
                    log("Error starting the server: " + e.getMessage());
                }
            }
        }).start();
    }
    
    private void rejectConnection(Socket clientSocket) {
        try {
        	PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
        	out.println("REJECTED"); // Send rejection message to the client
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    private String getClientName(Socket clientSocket) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            String clientName = reader.readLine();
            return clientName != null ? clientName : clientSocket.getInetAddress().getHostAddress();
        } catch (IOException e) {
            log("Error getting client name: " + e.getMessage());
            return clientSocket.getInetAddress().getHostAddress();
        }
    }

    public void broadcastMessage(String message) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                log(message);
            }
        });

        for (ClientHandler client : clients) {
            client.sendMessage(message);
        }
    }
    
    public void broadcastToClients(String message, ClientHandler sender) {
        for (ClientHandler client : clients) {
            if (client != sender) { // Skip sending the message back to the sender
                client.sendMessage(message);
            }
        }
    }


    private void stopServer() {
        try {
            serverSocket.close();
            log("Server stopped");
            connectedClients = 0;

            // Close all client handlers
            for (ClientHandler client : clients) {
                client.close();
            }
        } catch (IOException e) {
            log("Error stopping the server: " + e.getMessage());
        }
    }
    
    public void clientDisconnected(String clientName) {
        log("Client disconnected: " + clientName);
        clients.remove(clientName);
        connectedClients --;
        log("Number of clients connected: "+ connectedClients);
    }
    
    private void sendToClients() {
        String message = JOptionPane.showInputDialog(frame, "Enter message to send to clients:");
        if (message != null) {
            broadcastMessage("Server says: " + message);
        }
    }

    public void log(String message) {
        logTextArea.append(message + "\n");
    }

    
    }