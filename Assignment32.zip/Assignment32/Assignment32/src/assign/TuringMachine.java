package assign;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TuringMachine extends JFrame {

    private JTextArea tmTextArea;
    private JTextArea tapeTextArea;
    private JTextArea resultTextArea;

    public TuringMachine() {
    	
    	 setTitle("Turing Machine");
         setSize(700, 400);
         setResizable(false);
         setDefaultCloseOperation(DISPOSE_ON_CLOSE);
         setVisible(true);

         //initComponents();
    }

 public void initComponents(String tmTuples) {
    	
    	// Create a panel with BorderLayout
        JPanel grayPanel = new JPanel(new BorderLayout());
        grayPanel.setBackground(Color.LIGHT_GRAY);

        // Load the image for the top panel
        ImageIcon image = new ImageIcon("tm.png");
        JLabel imageLabel = new JLabel(image);
        grayPanel.add(imageLabel, BorderLayout.NORTH);
        
      
        tmTextArea = new JTextArea(tmTuples, 1, 40);
        tapeTextArea = new JTextArea("00000000000000000000000", 1, 25);
        resultTextArea = new JTextArea("", 5, 20);

        JButton simulateButton = new JButton("Run");
        JButton clearButton = new JButton("Clear");
        simulateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                simulateTuringMachine();
            }
        });
        
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	// Clear the text area
            	resultTextArea.setText("");
               
            }
        });

        JPanel inputPanel = new JPanel(new FlowLayout());
        inputPanel.add(new JLabel("              TM:"));
        inputPanel.add(new JScrollPane(tmTextArea));

        inputPanel.add(new JLabel("                              Tape:"));
        inputPanel.add(new JScrollPane(tapeTextArea));

        inputPanel.add(simulateButton);
        inputPanel.add(clearButton);

        JPanel resultPanel = new JPanel(new GridLayout(1, 1));
        resultPanel.add(new JScrollPane(resultTextArea));
        
     // Set a preferred size for the button panel
        inputPanel.setPreferredSize(new Dimension(0, 75));

        setLayout(new BorderLayout());
        add(grayPanel, BorderLayout.NORTH);
        add(inputPanel, BorderLayout.SOUTH);
        add(resultPanel, BorderLayout.CENTER);
    }

    
 private void simulateTuringMachine() {
     String tmInput = tmTextArea.getText();
     String tapeInput = tapeTextArea.getText();

     // Split the TM input into individual tuples
     String[] tuples = tmInput.split(" ");

     // Initialize the tape
     char[] tape = tapeInput.toCharArray();

     // Initial tape position
     int tapePos = tape.length / 2;

     // Display card information
     resultTextArea.setText("Card: " + tmInput + "\n\n");

     // Display initial tape configuration
     resultTextArea.append("Initial tape (head position between brackets):\n" + getTapeString(tape, tapePos) + "\n\n");
     resultTextArea.append("Game started\n");

     // Simulation loop
     for (int step = 0; step < tuples.length; step++) {
         // Get the current tuple
         String tuple = tuples[step];

         // Parse tuple components
         int currentState = Character.getNumericValue(tuple.charAt(0));
         char inputSymbol = tuple.charAt(1);
         int newState = Character.getNumericValue(tuple.charAt(2));
         char writeSymbol = tuple.charAt(3);
         int direction = Character.getNumericValue(tuple.charAt(4));

         // Check if the current state matches
         if (currentState == Character.getNumericValue(tape[tapePos])) {
             // Update tape symbol
             tape[tapePos] = writeSymbol;

             // Display step information
             resultTextArea.append("Step=" + step + ",\tTapepos=" + tapePos + ",\tFinalState=" + newState +
                     ",\ta[" + currentState + "],\tb[" + inputSymbol + "]=0,\tc[" + newState + "]=0,\td[" +
                     writeSymbol + "]=1,\te[" + direction + "]=0\n" + getTapeString(tape, tapePos) + "\n\n");

             // Move tape head
             if (direction == 0) {
                 tapePos--;  // Move left
             } else if (direction == 1) {
                 tapePos++;  // Move right
             }

             // Check for acceptance state
             if (newState == 0) {
                 resultTextArea.append("Final tape configuration is :\n" + getTapeString(tape, tapePos) + "\n\n");
                 return;
             }
         }
     }

     // If no acceptance state is reached
     resultTextArea.append("Final tape configuration is :\n" + getTapeString(tape, tapePos) + "\n\n");
 }

 private String getTapeString(char[] tape, int tapePos) {
     StringBuilder tapeString = new StringBuilder();
     for (int i = 0; i < tape.length; i++) {
         if (i == tapePos) {
             tapeString.append("[");
         }
         tapeString.append(tape[i]);
         if (i == tapePos) {
             tapeString.append("]");
         }
         tapeString.append(" ");
     }
     return tapeString.toString().trim();
 }
}