package assign;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;


public class Game extends JFrame implements ActionListener {
	int currentClientNumber =0;
    JButton setRuleButton = new JButton("OK");
    JButton button1 = new JButton("Cancel");
    JButton button2 = new JButton("Help");
    JComboBox<String> comboBox;
    
    Game() {

        ImageIcon image = new ImageIcon("CSmin.png");

        JLabel label = new JLabel();
        label.setIcon(image);

        setRuleButton.setFocusable(false);
        setRuleButton.addActionListener(this);
        setRuleButton.setFont(new Font("Comic Sans", Font.BOLD, 15));
        setRuleButton.setForeground(Color.BLUE);

        button1.addActionListener(this);
        button1.setFont(new Font("Comic Sans", Font.BOLD, 15));
        button1.setForeground(Color.BLUE);

        button2.addActionListener(this);
        button2.setFont(new Font("Comic Sans", Font.BOLD, 15));
        button2.setForeground(Color.BLUE);

        String[] game = {"[A12] CA - Cellular Automata", "[A22] GL - Game of Life", "[A32] TM - Turing Machine Server", "[A32] TM - Turing Machine Client"};
        comboBox = new JComboBox<>(game);
        comboBox.setPreferredSize(new Dimension(250, 30));
        comboBox.setForeground(Color.BLUE);

        setLayout(new BorderLayout());

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(setRuleButton);
        bottomPanel.add(button1);
        bottomPanel.add(button2);

        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(comboBox, BorderLayout.NORTH);

        add(label, BorderLayout.WEST);
        add(bottomPanel, BorderLayout.SOUTH);
        add(rightPanel, BorderLayout.EAST);

        setTitle("[JAP - Computer Science]");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 200);
        setResizable(false);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
		if (e.getSource()== setRuleButton) {
			
			if (comboBox.getSelectedItem() == "[A12] CA - Cellular Automata") {
				JOptionPane.showMessageDialog(null,  "This option is not integarted yet, but already developed.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }else if (comboBox.getSelectedItem().toString() == "[A22] GL - Game of Life") {
	            JOptionPane.showMessageDialog(null,  "This option is not integarted yet, but already developed", "Input Error", JOptionPane.ERROR_MESSAGE);
	                
        	
        	}else if (comboBox.getSelectedItem().toString()  == "[A32] TM - Turing Machine Server") {
        		Server server = new Server ();
        	              
                
        	}else if (comboBox.getSelectedItem().toString()  == "[A32] TM - Turing Machine Client") {
        		currentClientNumber++;
                Client client = new Client (currentClientNumber);
                
        	}
		
		}else if (e.getSource()== button1) {
			dispose();
		}else if (e.getSource()== button2) {
			JOptionPane.showMessageDialog(null,  "There are four options, but the only one game implement. So, please select A12 - Cellular Automata and click OK. ", "Help", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	
	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Game();
            }
        });
		

	}

}